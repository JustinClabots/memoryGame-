 /*
 * Create a list that holds all of your cards
 */
var cards = ['fa-diamond', 'fa-paper-plane-o', 'fa-anchor', 'fa-bolt', 'fa-cube',
                 'fa-leaf', 'fa-bomb', 'fa-diamond', 'fa-paper-plane-o', 'fa-anchor',
                 'fa-bolt', 'fa-cube', 'fa-leaf', 'fa-bomb', 'fa-bicycle', 'fa-bicycle'];



function generateCard(card) {
    return `<li class = "card" data-card="${card}"><i class="fa ${card}"></i></li>`;
};


/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(cardArray) {
    var currentIndex = cardArray.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = cardArray[currentIndex];
        cardArray[currentIndex] = cardArray[randomIndex];
        cardArray[randomIndex] = temporaryValue;
    }

    return cardArray;
}


/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */


function initGame(){
  var deck = document.querySelector('.deck');


  var cardHTML = shuffle(cards).map(function(card) {
    return generateCard(card);
  });

  deck.innerHTML = cardHTML.join(' ');

  document.getElementById('moveCounter').innerHTML= 0;
}

initGame();





  var allCards = document.querySelectorAll('.card');
  var openCards = [];
  var moves = 0;
  var winCounter = 0;

  allCards.forEach(function(card) {
    card.addEventListener('click', function(e){

      if(!card.classList.contains('open') && !card.classList.contains('show') && !card.classList.contains('match')){
        openCards.push(card);
        card.classList.add('open', 'show');


      if(openCards.length == 2) {
        if(openCards[0].dataset.card == openCards[1].dataset.card){


          openCards[0].classList.add('match');
          openCards[0].classList.add('open');
          openCards[0].classList.add('show');

          openCards[1].classList.add('match');
          openCards[1].classList.add('open');
          openCards[1].classList.add('show');

          openCards = [];

          winCounter++;

          addMoves();

          checkWin();
          }
        else
        {setTimeout(function() {
            openCards.forEach(function(card) {
              card.classList.remove('open', 'show');
            });
            openCards = [];
          }, 700);

          addMoves();

        }
      }

    }
  });
});


function addMoves() {
  moves++;
  document.getElementById('moveCounter').innerHTML = moves;

}

function checkWin() {
  if(winCounter == 8){
    //gets the modal
    var modal = document.getElementById('theModal');

    var span = document.getElementsByClassName('close')[0];

    //sets the modal style to block
    modal.style.display = "block";

    //closes model when user presses x
    span.onclick = function(){
      modal.style.display = "none";
    }

  }
}

var restart = document.getElementById('restart1');
restart.addEventListener('click', function(){
  location.reload();
})


//Timer code
var seconds = 0;
var minutes = 0;
var hours = 0;

//Defining varriables to hold display value
var displaySeconds = 0;
var displayMinutes = 0;
var displayHours = 0;

function timer(){
  seconds++;

  //logic for incrementing next value
  if(seconds/60 === 1){
    seconds = 0;
    minutes++;

    if(minutes/60 ===1){
      minutes = 0;
      hours++;
    }
  }

  //adding zeros to the time if they are only 1 digit
  if(seconds < 10){
    displaySeconds = "0" + seconds.toString();
  }
  else {
    displaySeconds = seconds;
  }
  if(minutes < 10){
    displayMinutes = "0" + minutes.toString();
  }
  else{
    displayMinutes = minutes;
  }
  if(hours < 10){
    displayHours = "0" + hours.toString();
  }
  else{
    displayHours = hours;
  }

//displaying the time
document.getElementById('display').innerHTML = displayHours + ":" + displayMinutes + ":" + displaySeconds;

}

//this runs the function every second
window.setInterval(timer, 1000);
